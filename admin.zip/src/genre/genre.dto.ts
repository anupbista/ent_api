import { ApiProperty } from '@nestjs/swagger';

export class GenreDTO{
    
    @ApiProperty()
    name: string; 

}