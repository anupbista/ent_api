export const jwtConstants = {
    secret: 'idCfs>g"X|t1H]S'
  };