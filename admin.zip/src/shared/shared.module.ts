import { Module } from '@nestjs/common';

@Module({})
export class SharedModule {}
