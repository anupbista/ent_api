import { Controller } from '@nestjs/common';

@Controller('userinfo')
export class UserInfoController {}
